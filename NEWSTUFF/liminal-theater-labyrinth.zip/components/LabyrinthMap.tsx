
import React from 'react';
import { TheaterRoom, Edge } from '../types';

interface Props {
  rooms: TheaterRoom[];
  edges: Record<string, Edge>;
  onEnter: (id: string) => void;
}

const LabyrinthMap: React.FC<Props> = ({ rooms, edges, onEnter }) => {
  return (
    <div className="liminal-tile min-h-full p-12 overflow-auto flex items-center justify-center relative">
      {/* Background Traffic Overlay (Simplified visualization) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
        {Object.values(edges).map((edge, idx) => {
          if (edge.traffic < 0.5) return null;
          return (
            <div 
              key={idx}
              className="absolute bg-white/10 blur-xl animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                width: `${edge.traffic * 10}px`,
                height: `${edge.traffic * 10}px`,
              }}
            ></div>
          );
        })}
      </div>

      <div className="grid grid-cols-6 gap-x-12 gap-y-16 perspective-1000 relative z-10">
        {rooms.map((room) => {
          const glowColor = room.dominantColor || '#00000000';
          const composition = room.compositionKey || '0-0-0-0';
          
          return (
            <div 
              key={room.id}
              onClick={() => onEnter(room.id)}
              className={`
                relative w-32 h-48 cursor-pointer transition-all duration-700 
                group hover:scale-110 hover:-translate-y-2
              `}
            >
              {/* Monsters Inc Glow Effect */}
              {room.owner && (
                <div 
                  className="absolute -inset-2 blur-2xl opacity-40 transition-opacity group-hover:opacity-80 rounded-t-2xl animate-pulse"
                  style={{ backgroundColor: glowColor }}
                ></div>
              )}

              {/* Aesthetic Biome Indicator (Subtle shadow shift) */}
              {room.vibeVector && (
                <div 
                  className="absolute inset-0 -z-10 blur-lg opacity-10"
                  style={{ backgroundColor: room.vibeVector.palette[2] }}
                ></div>
              )}

              {/* The Door Frame */}
              <div 
                className={`
                  absolute inset-0 bg-slate-900 border-x-4 border-t-8 border-slate-800 rounded-t-xl shadow-2xl overflow-hidden
                  ${room.owner ? 'border-opacity-100' : 'border-opacity-30'}
                `}
                style={room.owner ? { borderColor: `${glowColor}66` } : {}}
              >
                {/* Door Surface */}
                <div 
                  className={`
                    absolute inset-1 rounded-t-lg border border-white/5 flex flex-col items-center justify-center text-center p-2 transition-colors duration-1000
                    ${room.owner ? 'bg-slate-950' : 'bg-slate-900/50'}
                  `}
                >
                  <div 
                    className="w-1.5 h-1.5 rounded-full shadow-lg mb-4"
                    style={{ backgroundColor: room.owner ? glowColor : '#334155' }}
                  ></div>
                  
                  <span className="theater-font text-slate-300 text-xl font-bold opacity-90 mb-1">
                    {room.id}
                  </span>

                  {room.owner ? (
                    <div className="flex flex-col items-center">
                       <span className="text-[11px] text-white/70 uppercase tracking-[0.2em] font-bold">Occupied</span>
                       <div className="mt-1 text-[10px] text-slate-400 font-mono italic">
                         {composition}
                       </div>
                       <div className="mt-1 text-[11px] text-amber-500 font-mono italic uppercase font-bold">
                         {room.condition}
                       </div>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-500 uppercase tracking-tighter font-bold">Void</span>
                  )}
                  
                  {/* Subtle Light Leak */}
                  {room.owner && (
                    <div 
                      className="absolute bottom-0 w-full h-1 bg-white/20 blur-sm"
                      style={{ backgroundColor: glowColor }}
                    ></div>
                  )}
                </div>

                {/* Handle */}
                <div className={`absolute right-3 top-1/2 -translate-y-1/2 w-2 h-6 bg-slate-700 rounded-full shadow-lg border border-white/5`}></div>
              </div>

              {/* Fluorescent Light above door */}
              <div className="absolute -top-10 left-1/2 -translate-x-1/2 flex flex-col items-center opacity-40 group-hover:opacity-100 transition-opacity">
                <div className="w-14 h-1.5 bg-slate-200 rounded-full shadow-[0_0_15px_rgba(255,255,255,0.5)] flicker"></div>
                <div className="w-20 h-10 bg-white/5 blur-xl flicker rounded-full"></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LabyrinthMap;
