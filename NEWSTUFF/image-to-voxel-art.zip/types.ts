
export enum TileType {
  VOID = 'VOID',
  STRAIGHT = 'STRAIGHT',
  CORNER = 'CORNER',
  T = 'T',
  X = 'X',
  DOOR_FRAME = 'DOOR_FRAME',
  HALL_END = 'HALL_END',
}

export type Direction = 'N' | 'E' | 'S' | 'W';

export interface VibeVector {
  warmth: number; // 0 (cold/blue) to 1 (warm/orange)
  saturation: number;
  entropy: number; // 0 (pristine) to 1 (decayed/glitchy)
  flicker: number; // probability of light flicker
  grain: number; // post-processing noise
  palette: string[]; // hex colors
}

export interface TheaterRoom {
  id: string;
  name: string;
  vibe: VibeVector;
  condition: 'pristine' | 'modern' | 'dusty' | 'abandoned' | 'fallout';
  assets: string[];
  imageUrl?: string;
  ownerId?: string;
}

export interface Edge {
  from: string;
  to: string;
  traffic: number;
}

export interface HallwayTile {
  id: string;
  type: TileType;
  x: number;
  y: number;
  rotation: number; // 0, 90, 180, 270
  variant: string;
  trafficStrength: number;
  connections: Record<Direction, boolean>;
}
