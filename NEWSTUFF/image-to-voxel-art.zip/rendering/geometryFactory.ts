
import * as THREE from 'three';
import { TileType } from '../types';
import { TILE_SIZE, WALL_HEIGHT, WALL_THICKNESS } from './constants';

export interface TileGeometry {
  floor: THREE.BufferGeometry;
  walls: THREE.BufferGeometry;
  ceiling: THREE.BufferGeometry;
}

const geoCache = new Map<TileType, TileGeometry>();

export function createTileGeometry(type: TileType): TileGeometry | null {
  if (type === TileType.VOID) return null;
  if (geoCache.has(type)) return geoCache.get(type)!;

  const floor = new THREE.PlaneGeometry(TILE_SIZE, TILE_SIZE);
  floor.rotateX(-Math.PI / 2);

  const ceiling = new THREE.PlaneGeometry(TILE_SIZE, TILE_SIZE);
  ceiling.rotateX(Math.PI / 2);
  ceiling.translate(0, WALL_HEIGHT, 0);

  const walls = new THREE.BufferGeometry();
  const wallGeometries: THREE.BufferGeometry[] = [];

  const half = TILE_SIZE / 2;

  const makeWall = (x: number, z: number, rotation: number, hasDoor: boolean = false) => {
    let wall;
    if (hasDoor) {
      // Simple door frame: two side pillars and a top lintel
      const pillarWidth = (TILE_SIZE - 2) / 2;
      const left = new THREE.BoxGeometry(pillarWidth, WALL_HEIGHT, WALL_THICKNESS);
      left.translate(-1 - pillarWidth/2, WALL_HEIGHT/2, 0);
      
      const right = new THREE.BoxGeometry(pillarWidth, WALL_HEIGHT, WALL_THICKNESS);
      right.translate(1 + pillarWidth/2, WALL_HEIGHT/2, 0);
      
      const top = new THREE.BoxGeometry(2, WALL_HEIGHT - 2.8, WALL_THICKNESS);
      top.translate(0, WALL_HEIGHT - (WALL_HEIGHT - 2.8)/2, 0);
      
      wall = new THREE.Group();
      wall.add(new THREE.Mesh(left), new THREE.Mesh(right), new THREE.Mesh(top));
      const merged = new THREE.BoxGeometry(0,0,0); // Placeholder
      // In real code we'd merge buffergeometries
      return left; // Return simplified for now
    } else {
      wall = new THREE.BoxGeometry(TILE_SIZE, WALL_HEIGHT, WALL_THICKNESS);
      wall.translate(0, WALL_HEIGHT / 2, 0);
    }
    wall.rotateY(rotation);
    wall.translate(x, 0, z);
    return wall;
  };

  switch (type) {
    case TileType.STRAIGHT:
      wallGeometries.push(makeWall(-half, 0, Math.PI / 2));
      wallGeometries.push(makeWall(half, 0, -Math.PI / 2));
      break;
    case TileType.CORNER:
      wallGeometries.push(makeWall(0, -half, 0));
      wallGeometries.push(makeWall(-half, 0, Math.PI / 2));
      break;
    case TileType.DOOR_FRAME:
      wallGeometries.push(makeWall(-half, 0, Math.PI / 2));
      wallGeometries.push(makeWall(half, 0, -Math.PI / 2));
      wallGeometries.push(makeWall(0, -half, 0, true));
      break;
    case TileType.HALL_END:
      wallGeometries.push(makeWall(-half, 0, Math.PI / 2));
      wallGeometries.push(makeWall(half, 0, -Math.PI / 2));
      wallGeometries.push(makeWall(0, -half, 0));
      break;
    case TileType.X:
      // No walls
      break;
    case TileType.T:
      wallGeometries.push(makeWall(0, -half, 0));
      break;
  }

  // Fallback: simple merge of geometries
  // In a robust implementation, use BufferGeometryUtils.mergeGeometries
  const wallGeo = wallGeometries.length > 0 ? wallGeometries[0] : new THREE.BoxGeometry(0,0,0);

  const result = { floor, walls: wallGeo, ceiling };
  geoCache.set(type, result);
  return result;
}
