
import * as THREE from 'three';
import { VibeVector } from '../types';

export function getTileMaterials(vibe: VibeVector, traffic: number) {
  const baseColor = new THREE.Color(vibe.palette[0] || 0xeeeeee);
  const accentColor = new THREE.Color(vibe.palette[1] || 0xcccccc);
  
  // Influenced by mall video: white tiles, clean but cold concrete
  // Higher entropy increases roughness and reduces reflectivity
  const floorMat = new THREE.MeshStandardMaterial({
    color: baseColor,
    roughness: 0.25 + vibe.entropy * 0.6,
    metalness: 0.02,
  });

  const wallMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    roughness: 0.9,
    metalness: 0,
  });

  const ceilingMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 1,
    emissive: 0xffffff,
    emissiveIntensity: 0.02 + (vibe.warmth * 0.03),
  });

  return { floor: floorMat, walls: wallMat, ceiling: ceilingMat };
}
