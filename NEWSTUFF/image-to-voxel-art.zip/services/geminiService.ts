
import { GoogleGenAI, Type } from "@google/genai";
import { VibeVector, TheaterRoom } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeFlavor(prompt: string): Promise<Partial<TheaterRoom>> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following prompt and extract a "vibe" for a liminal theater/mall room.
    Prompt: "${prompt}"
    
    Respond in JSON format with:
    - warmth (0-1)
    - saturation (0-1)
    - entropy (0-1)
    - condition (pristine, modern, dusty, abandoned, fallout)
    - palette (array of 3 hex colors)
    - name (evocative name)
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          warmth: { type: Type.NUMBER },
          saturation: { type: Type.NUMBER },
          entropy: { type: Type.NUMBER },
          condition: { type: Type.STRING },
          palette: { type: Type.ARRAY, items: { type: Type.STRING } },
          name: { type: Type.STRING },
        },
        required: ["warmth", "saturation", "entropy", "condition", "palette", "name"]
      }
    }
  });

  const data = JSON.parse(response.text);
  return {
    name: data.name,
    condition: data.condition,
    vibe: {
      warmth: data.warmth,
      saturation: data.saturation,
      entropy: data.entropy,
      flicker: data.entropy * 0.2,
      grain: data.entropy * 0.1,
      palette: data.palette
    }
  };
}

export async function generateRoomImage(prompt: string, vibe: VibeVector): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: `A liminal room in a vast theater labyrinth. ${prompt}. Atmospheric lighting, cinematic, 8k, photorealistic, empty, nostalgic.`,
    config: {
      imageConfig: { aspectRatio: "16:9" }
    }
  });

  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return part ? `data:image/png;base64,${part.inlineData.data}` : "";
}
