
import { TileType, HallwayTile, TheaterRoom, Edge, Direction } from '../types';

export function generateLabyrinthLayout(
  rooms: Record<string, TheaterRoom>,
  edges: Record<string, Edge>,
  gridSize: number = 24
): Record<string, HallwayTile> {
  const layout: Record<string, HallwayTile> = {};

  // Simple seed-based or deterministic generation for now
  // In a real impl, this would crawl edges and rooms to build the path
  for (let x = -gridSize / 2; x < gridSize / 2; x++) {
    for (let y = -gridSize / 2; y < gridSize / 2; y++) {
      const key = `${x},${y}`;
      
      // Deterministic noise for layout
      const val = (Math.sin(x * 0.5) * Math.cos(y * 0.5)) + (Math.sin(x * 0.1) * 0.5);
      
      if (val > 0.4) {
        // Determine type based on neighbors (simplified)
        let type = TileType.STRAIGHT;
        let rotation = 0;
        
        // Pseudo-randomly place doors
        const doorChance = Math.abs(Math.sin(x * 10 + y * 5));
        if (doorChance > 0.85) {
          type = TileType.DOOR_FRAME;
        } else if (doorChance < 0.1) {
          type = TileType.CORNER;
          rotation = Math.floor(Math.random() * 4) * 90;
        }

        layout[key] = {
          id: key,
          type,
          x,
          y,
          rotation,
          variant: 'neutral-modern',
          trafficStrength: 0.1,
          connections: { N: true, S: true, E: true, W: true } // Simplified
        };
      }
    }
  }

  return layout;
}
