
import { create } from 'zustand';
import { TheaterRoom, Edge, VibeVector } from '../types';

interface LabyrinthState {
  rooms: Record<string, TheaterRoom>;
  edges: Record<string, Edge>;
  playerRoomId: string | null;
  position: [number, number, number];
  rotation: [number, number, number];
  
  setRooms: (rooms: Record<string, TheaterRoom>) => void;
  claimRoom: (id: string, room: TheaterRoom) => void;
  updatePlayer: (pos: [number, number, number], rot: [number, number, number]) => void;
}

export const useLabyrinthStore = create<LabyrinthState>((set) => ({
  rooms: {},
  edges: {},
  playerRoomId: null,
  position: [0, 1.7, 0],
  rotation: [0, 0, 0],
  
  setRooms: (rooms) => set({ rooms }),
  claimRoom: (id, room) => set((state) => ({
    rooms: { ...state.rooms, [id]: room }
  })),
  updatePlayer: (position, rotation) => set({ position, rotation })
}));
