
import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { useLabyrinthStore } from './store/labyrinthStore';
import { generateLabyrinthLayout } from './services/hallwayService';
import { createTileGeometry } from './rendering/geometryFactory';
import { getTileMaterials } from './rendering/materialFactory';
import { TILE_SIZE, PLAYER_HEIGHT } from './rendering/constants';
import { TileType, VibeVector, HallwayTile } from './types';
import { analyzeFlavor } from './services/geminiService';

const DEFAULT_VIBE: VibeVector = {
  warmth: 0.5,
  saturation: 0.5,
  entropy: 0.1,
  flicker: 0,
  grain: 0,
  palette: ['#ffffff', '#f0f0f0', '#cccccc']
};

const Minimap: React.FC<{ tiles: Record<string, HallwayTile>, playerPos: THREE.Vector3, rooms: any }> = ({ tiles, playerPos, rooms }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const scale = 2.5;
    const center = canvas.width / 2;

    Object.values(tiles).forEach(tile => {
      const x = center + tile.x * scale;
      const y = center + tile.y * scale;
      
      ctx.fillStyle = rooms[tile.id] ? (rooms[tile.id].vibe.palette[0] || '#fff') : 'rgba(255,255,255,0.1)';
      if (tile.type === TileType.DOOR_FRAME) ctx.fillStyle = '#ff3366';
      
      ctx.fillRect(x, y, scale - 0.2, scale - 0.2);
    });

    // Player
    ctx.fillStyle = '#00ffcc';
    ctx.beginPath();
    ctx.arc(center + (playerPos.x / TILE_SIZE) * scale, center + (playerPos.z / TILE_SIZE) * scale, 1.5, 0, Math.PI * 2);
    ctx.fill();
  }, [tiles, playerPos, rooms]);

  return <canvas ref={canvasRef} width={128} height={128} className="w-32 h-32 border border-white/10" />;
};

const App: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [isSyncing, setIsSyncing] = useState(true);
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [claimPrompt, setClaimPrompt] = useState('');
  const [targetTileId, setTargetTileId] = useState<string | null>(null);
  const [playerPos, setPlayerPos] = useState(new THREE.Vector3(0, 0, 5));

  const { rooms, claimRoom } = useLabyrinthStore();
  
  const tiles = useMemo(() => generateLabyrinthLayout(rooms, {}), [rooms]);

  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);
    scene.fog = new THREE.FogExp2(0x0a0a0a, 0.08);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, PLAYER_HEIGHT, 5);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    const canvas = renderer.domElement;
    containerRef.current.appendChild(canvas);

    const controls = new PointerLockControls(camera, canvas);
    
    controls.addEventListener('lock', () => setIsLocked(true));
    controls.addEventListener('unlock', () => setIsLocked(false));

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.1);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xffffff, 20, 15);
    camera.add(pointLight);
    scene.add(camera);

    const labyrinthGroup = new THREE.Group();
    scene.add(labyrinthGroup);

    // Build Labyrinth Meshes
    Object.values(tiles).forEach(tile => {
      const geo = createTileGeometry(tile.type);
      if (!geo) return;

      const vibe = rooms[tile.id]?.vibe || DEFAULT_VIBE;
      const mats = getTileMaterials(vibe, tile.trafficStrength);

      const group = new THREE.Group();
      group.add(new THREE.Mesh(geo.floor, mats.floor));
      group.add(new THREE.Mesh(geo.walls, mats.walls));
      group.add(new THREE.Mesh(geo.ceiling, mats.ceiling));

      group.position.set(tile.x * TILE_SIZE, 0, tile.y * TILE_SIZE);
      group.rotation.y = THREE.MathUtils.degToRad(tile.rotation);
      group.userData = { id: tile.id, type: tile.type };
      labyrinthGroup.add(group);
    });

    // Mark sync as complete after generation
    const syncTimer = setTimeout(() => setIsSyncing(false), 1500);

    const moveState = { f: false, b: false, l: false, r: false };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyW') moveState.f = true;
      if (e.code === 'KeyS') moveState.b = true;
      if (e.code === 'KeyA') moveState.l = true;
      if (e.code === 'KeyD') moveState.r = true;
      
      if (e.code === 'KeyE' && !showClaimModal && controls.isLocked) {
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
        const intersects = raycaster.intersectObjects(labyrinthGroup.children, true);
        
        for (const intersect of intersects) {
          let current: THREE.Object3D | null = intersect.object;
          while (current && !current.userData.id) {
            current = current.parent;
          }
          if (current && current.userData.type === TileType.DOOR_FRAME) {
            setTargetTileId(current.userData.id);
            controls.unlock();
            setShowClaimModal(true);
            break;
          }
        }
      }
    };
    
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'KeyW') moveState.f = false;
      if (e.code === 'KeyS') moveState.b = false;
      if (e.code === 'KeyA') moveState.l = false;
      if (e.code === 'KeyD') moveState.r = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const clock = new THREE.Clock();
    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const speed = 6 * delta;

      if (controls.isLocked) {
        if (moveState.f) controls.moveForward(speed);
        if (moveState.b) controls.moveForward(-speed);
        if (moveState.l) controls.moveRight(-speed);
        if (moveState.r) controls.moveRight(speed);
        
        // Update player position state for minimap
        setPlayerPos(camera.position.clone());
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearTimeout(syncTimer);
      cancelAnimationFrame(animId);
      renderer.dispose();
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && canvas.parentNode === containerRef.current) {
        containerRef.current.removeChild(canvas);
      }
    };
  }, [rooms, tiles, showClaimModal]);

  const handleClaim = async () => {
    if (!targetTileId || !claimPrompt) return;
    try {
      const flavor = await analyzeFlavor(claimPrompt);
      claimRoom(targetTileId, {
        id: targetTileId,
        name: flavor.name || 'Unknown Room',
        vibe: flavor.vibe || DEFAULT_VIBE,
        condition: flavor.condition as any || 'modern',
        assets: []
      });
      setShowClaimModal(false);
      setClaimPrompt('');
    } catch (error) {
      console.error("Manifestation failed:", error);
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black font-sans text-white">
      <div 
        ref={containerRef} 
        className="w-full h-full cursor-crosshair" 
        onClick={() => {
            if (!showClaimModal) {
                document.body.requestPointerLock();
            }
        }} 
      />
      
      {!isLocked && !showClaimModal && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70 pointer-events-none transition-opacity duration-500">
          <div className="text-center p-12 border border-white/10 bg-black/40 backdrop-blur-xl rounded-3xl">
            <h1 className="text-7xl font-black tracking-tighter uppercase mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500">
              Theater Labyrinth
            </h1>
            <p className="text-xl font-medium text-gray-400 mb-8 max-w-md mx-auto">
              A procedural social space in the liminal echoes of a 1990s mall.
            </p>
            <div className="flex flex-col gap-4 items-center">
              <div className="px-8 py-4 bg-white text-black font-black uppercase text-sm tracking-widest cursor-pointer pointer-events-auto hover:bg-gray-200 transition-colors" onClick={() => {
                document.body.requestPointerLock();
              }}>
                Initialize Node
              </div>
              <div className="mt-8 flex gap-6 justify-center opacity-60">
                <div className="flex flex-col items-center">
                  <span className="text-[10px] uppercase font-bold text-gray-500">Movement</span>
                  <span className="text-xs uppercase font-black">WASD</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-[10px] uppercase font-bold text-gray-500">Manifest</span>
                  <span className="text-xs uppercase font-black">E key</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-[10px] uppercase font-bold text-gray-500">Unlock</span>
                  <span className="text-xs uppercase font-black">ESC</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showClaimModal && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-50 animate-in fade-in duration-300">
          <div className="w-full max-w-lg p-10 border border-white bg-black shadow-[12px_12px_0px_0px_white] rounded-none">
            <h2 className="text-3xl font-black uppercase mb-2">Claim Node</h2>
            <p className="text-[10px] text-gray-500 mb-8 uppercase tracking-[0.3em] font-bold">Node ID: {targetTileId}</p>
            
            <label className="block text-[10px] uppercase font-black mb-2 tracking-widest text-gray-400">Atmospheric Prompt</label>
            <textarea 
              autoFocus
              className="w-full h-32 p-4 bg-white/5 border border-white/20 focus:border-white focus:outline-none mb-8 text-lg font-medium resize-none transition-colors"
              placeholder="Describe the echoes of this room..."
              value={claimPrompt}
              onChange={e => setClaimPrompt(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && e.metaKey) handleClaim();
              }}
            />
            
            <div className="flex justify-between items-center">
               <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">CMD+ENTER to Manifest</span>
               <div className="flex gap-4">
                <button 
                  onClick={() => setShowClaimModal(false)}
                  className="px-6 py-2 uppercase font-black text-xs border border-white/20 hover:bg-white/5 hover:border-white transition-all"
                >
                  Close
                </button>
                <button 
                  onClick={handleClaim}
                  className="px-6 py-2 uppercase font-black text-xs bg-white text-black hover:bg-gray-200 transition-all"
                >
                  Manifest Space
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="absolute top-8 left-8 p-6 border border-white/10 bg-black/20 backdrop-blur-2xl pointer-events-none rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-yellow-500 animate-pulse' : 'bg-green-500'}`} />
          <div className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-black">
            {isSyncing ? 'Syncing Environment' : 'Connection Established'}
          </div>
        </div>
        <div className="text-2xl font-black uppercase tracking-tight">Node Explorer</div>
        <div className="text-[10px] uppercase text-gray-500 font-bold tracking-widest mt-1">Labyrinth Index: Mall-3-B</div>
        
        <div className="mt-8 flex flex-col gap-4">
            <Minimap tiles={tiles} playerPos={playerPos} rooms={rooms} />
            
            <div className="flex flex-col">
              <div className="w-48 h-1 bg-white/5 relative overflow-hidden">
                  {isSyncing ? (
                    <div className="absolute top-0 left-0 h-full bg-white/40 w-1/3 animate-[shimmer_2s_infinite]" />
                  ) : (
                    <div className="absolute top-0 left-0 h-full bg-green-500/40 w-full" />
                  )}
              </div>
              <div className={`mt-2 text-[9px] uppercase font-black tracking-widest ${isSyncing ? 'text-white/30' : 'text-green-400/60'}`}>
                {isSyncing ? 'Syncing Labyrinth Topology...' : 'Topology Synchronized'}
              </div>
            </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(300%); }
        }
      `}} />
    </div>
  );
};

export default App;
